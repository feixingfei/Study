package com.bjpowernode;

import jakarta.annotation.Resource;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.kafka.core.ConsumerFactory;

@SpringBootApplication
public class KafkaBaseApplication {

    @Resource
    private ConsumerFactory<String, String> consumerFactory;

    public static void main(String[] args) {
        SpringApplication.run(KafkaBaseApplication.class, args);
    }
}
