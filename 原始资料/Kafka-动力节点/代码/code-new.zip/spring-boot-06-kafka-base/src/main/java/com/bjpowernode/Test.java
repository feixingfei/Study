package com.bjpowernode;

public class Test {

    public static void main(String[] args) {
        int partition = Math.abs("myGroupx2".hashCode()) % 50;
        System.out.println(partition);
    }
}
